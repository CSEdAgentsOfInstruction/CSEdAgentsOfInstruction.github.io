print("********")
print("Welcome!")
print("********")
