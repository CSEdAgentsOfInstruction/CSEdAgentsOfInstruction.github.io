print"Welcome!")
