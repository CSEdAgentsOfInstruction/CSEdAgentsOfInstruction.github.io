# Agent sandbox for the workshop

This folder sets up a Docker container where an AI agent can work without
access to the files on your computer.

1. Install Docker, VS Code and the Dev Containers extension.
2. Open this folder in VS Code and choose "Reopen in Container".
3. Follow the workshop guide for signing in and moving files in and out.

The settings are in the .devcontainer folder, which your file manager may hide.
